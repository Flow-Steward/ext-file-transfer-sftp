"""Async client for AWS services, wrapping botocore with aiohttp/httpx."""

__version__ = '3.10.0+flowsteward.2'

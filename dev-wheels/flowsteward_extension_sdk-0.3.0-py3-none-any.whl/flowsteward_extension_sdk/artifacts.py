from __future__ import annotations

import contextlib
import hashlib
import json
import os
import tempfile
import time
import uuid
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import quote, unquote, urlparse
from urllib.request import Request

from .http import (
    PinnedPeerError,
    open_pinned_url,
    open_platform_artifact_url,
    verified_platform_grant_signature,
)
from .progress import announce_output_ready

_MESSAGE_ARTIFACT_BODY_EXCEEDS_GRANTED_SIZE_LIMIT = "Artifact body exceeds granted size limit"
_MESSAGE_MAX_SIZE_BYTES_MUST_BE_A_POSITIVE_INTEGER = "max_size_bytes must be a positive integer"
_MESSAGE_OBJECT_STREAM_EXCEEDS_MAX_SIZE_BYTES = "object stream exceeds max_size_bytes"

APPLICATION_JSON_VALUE = "application/json"
OCTET_STREAM_VALUE = "application/octet-stream"
RETENTION_CLASSES = {"ephemeral", "run_window", "audit", "persistent"}
_consumed_platform_grants: set[str] = set()


def _artifact_metadata_key(artifact_id: str) -> str:
    return f"artifacts/_metadata/{str(artifact_id or '').strip()}.json"


class ArtifactAccessError(RuntimeError):
    """Raised when a payload artifact grant cannot be used by the extension."""


class ObjectStorageAdapter(Protocol):
    def put(self, key: str, body: bytes, *, content_type: str) -> dict[str, Any]: ...

    def put_stream(
        self,
        key: str,
        chunks: Iterable[bytes],
        *,
        content_type: str,
        max_size_bytes: int,
    ) -> dict[str, Any]: ...

    def get(self, key: str) -> bytes | None: ...

    def stream(self, key: str, *, chunk_size: int = 1024 * 1024) -> Iterator[bytes]: ...

    def stat(self, key: str) -> dict[str, Any] | None: ...

    def delete(self, key: str) -> bool: ...

    def presign(self, key: str, *, method: str, ttl_seconds: int = 600) -> str: ...


class InMemoryObjectStorage:
    def __init__(self, *, key_prefix: str = "") -> None:
        self._objects: dict[str, dict[str, Any]] = {}
        self._key_prefix = str(key_prefix or "").strip().strip("/")
        self.key_prefix = f"{self._key_prefix}/" if self._key_prefix else ""

    def _full_key(self, key: str) -> str:
        safe = str(key or "").strip().lstrip("/")
        return f"{self._key_prefix}/{safe}" if self._key_prefix else safe

    def put(self, key: str, body: bytes, *, content_type: str) -> dict[str, Any]:
        payload = bytes(body)
        checksum = hashlib.sha256(payload).hexdigest()
        self._objects[self._full_key(key)] = {
            "body": payload,
            "content_type": str(content_type or OCTET_STREAM_VALUE).strip(),
            "size_bytes": len(payload),
            "sha256": checksum,
        }
        return {"key": key, "size_bytes": len(payload), "sha256": checksum}

    def put_stream(
        self,
        key: str,
        chunks: Iterable[bytes],
        *,
        content_type: str,
        max_size_bytes: int,
    ) -> dict[str, Any]:
        max_size = _as_positive_int(max_size_bytes)
        if max_size is None:
            raise ValueError(_MESSAGE_MAX_SIZE_BYTES_MUST_BE_A_POSITIVE_INTEGER)
        payload = bytearray()
        digest = hashlib.sha256()
        size = 0
        try:
            for chunk in chunks:
                data = bytes(chunk or b"")
                if not data:
                    continue
                if size + len(data) > max_size:
                    raise ValueError(_MESSAGE_OBJECT_STREAM_EXCEEDS_MAX_SIZE_BYTES)
                payload.extend(data)
                digest.update(data)
                size += len(data)
            body = bytes(payload)
            checksum = digest.hexdigest()
            self._objects[self._full_key(key)] = {
                "body": body,
                "content_type": str(content_type or OCTET_STREAM_VALUE).strip(),
                "size_bytes": size,
                "sha256": checksum,
            }
            return {"key": key, "size_bytes": size, "sha256": checksum}
        except Exception:
            self.delete(key)
            raise

    def get(self, key: str) -> bytes | None:
        row = self._objects.get(self._full_key(key))
        return bytes(row["body"]) if row else None

    def stream(self, key: str, *, chunk_size: int = 1024 * 1024) -> Iterator[bytes]:
        body = self.get(key)
        if body is None:
            return
        size = max(1, int(chunk_size or 1))
        for offset in range(0, len(body), size):
            yield body[offset : offset + size]

    def stat(self, key: str) -> dict[str, Any] | None:
        row = self._objects.get(self._full_key(key))
        if not row:
            return None
        return {
            "key": key,
            "size_bytes": int(row.get("size_bytes") or 0),
            "sha256": str(row.get("sha256") or "").strip(),
        }

    def delete(self, key: str) -> bool:
        return self._objects.pop(self._full_key(key), None) is not None

    def presign(self, key: str, *, method: str, ttl_seconds: int = 600) -> str:
        safe_method = str(method or "GET").strip().upper()
        ttl = max(60, min(int(ttl_seconds or 600), 3600))
        return f"inmemory://{key}?method={safe_method}&ttl={ttl}"


class LocalFilesystemStorageAdapter:
    def __init__(self, *, root_dir: str, key_prefix: str = "") -> None:
        self._root = os.path.abspath(str(root_dir or "/data/artifacts"))
        self._key_prefix = str(key_prefix or "").strip().strip("/")
        self.key_prefix = f"{self._key_prefix}/" if self._key_prefix else ""
        os.makedirs(self._root, exist_ok=True)

    def _full_key(self, key: str) -> str:
        safe = str(key or "").strip().lstrip("/")
        return f"{self._key_prefix}/{safe}" if self._key_prefix else safe

    def _path(self, key: str) -> str:
        full = os.path.abspath(os.path.join(self._root, self._full_key(key)))
        if os.path.commonpath([self._root, full]) != self._root:
            raise ValueError(f"Storage key escapes root: {key}")
        return full

    def put(self, key: str, body: bytes, *, content_type: str) -> dict[str, Any]:
        _ = content_type
        path = self._path(key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = bytes(body)
        checksum = hashlib.sha256(payload).hexdigest()
        with open(path, "wb") as handle:
            handle.write(payload)
        return {"key": key, "size_bytes": len(payload), "sha256": checksum}

    def put_stream(
        self,
        key: str,
        chunks: Iterable[bytes],
        *,
        content_type: str,
        max_size_bytes: int,
    ) -> dict[str, Any]:
        _ = content_type
        max_size = _as_positive_int(max_size_bytes)
        if max_size is None:
            raise ValueError(_MESSAGE_MAX_SIZE_BYTES_MUST_BE_A_POSITIVE_INTEGER)
        path = self._path(key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            prefix=f".{os.path.basename(path) or 'object'}.",
            suffix=".tmp",
            dir=os.path.dirname(path),
        )
        digest = hashlib.sha256()
        size = 0
        try:
            with os.fdopen(fd, "wb") as handle:
                for chunk in chunks:
                    data = bytes(chunk or b"")
                    if not data:
                        continue
                    if size + len(data) > max_size:
                        raise ValueError(_MESSAGE_OBJECT_STREAM_EXCEEDS_MAX_SIZE_BYTES)
                    handle.write(data)
                    digest.update(data)
                    size += len(data)
            os.replace(tmp_path, path)
            return {"key": key, "size_bytes": size, "sha256": digest.hexdigest()}
        except Exception:
            with contextlib.suppress(Exception):
                os.close(fd)
            with contextlib.suppress(Exception):
                os.remove(tmp_path)
            with contextlib.suppress(Exception):
                os.remove(path)
            raise

    def get(self, key: str) -> bytes | None:
        path = self._path(key)
        if not os.path.isfile(path):
            return None
        with open(path, "rb") as handle:
            return handle.read()

    def stream(self, key: str, *, chunk_size: int = 1024 * 1024) -> Iterator[bytes]:
        path = self._path(key)
        if not os.path.isfile(path):
            return
        with open(path, "rb") as handle:
            yield from iter(lambda: handle.read(max(1, int(chunk_size or 1))), b"")

    def stat(self, key: str) -> dict[str, Any] | None:
        path = self._path(key)
        if not os.path.isfile(path):
            return None
        return {"key": key, "size_bytes": os.path.getsize(path)}

    def delete(self, key: str) -> bool:
        path = self._path(key)
        if not os.path.isfile(path):
            return False
        os.remove(path)
        return True

    def presign(self, key: str, *, method: str, ttl_seconds: int = 600) -> str:
        safe_method = str(method or "GET").strip().upper()
        ttl = max(60, min(int(ttl_seconds or 600), 3600))
        return f"{Path(self._path(key)).as_uri()}?method={safe_method}&ttl={ttl}"


class S3ObjectStorageAdapter:
    def __init__(
        self,
        *,
        endpoint_url: str = "",
        public_endpoint_url: str = "",
        region: str = "us-east-1",
        bucket: str,
        access_key: str = "",
        secret_key: str = "",
        key_prefix: str = "",
        use_ssl: bool = True,
        addressing_style: str = "auto",
        presign_ttl_seconds: int = 600,
    ) -> None:
        import boto3
        from botocore import UNSIGNED
        from botocore.config import Config as BotoConfig

        session_kwargs: dict[str, Any] = {}
        if access_key and secret_key:
            session_kwargs["aws_access_key_id"] = access_key
            session_kwargs["aws_secret_access_key"] = secret_key
        config_kwargs: dict[str, Any] = {
            "s3": {"addressing_style": addressing_style or "auto"},
            "signature_version": "s3v4",
        }
        if endpoint_url and not access_key and not secret_key:
            config_kwargs["signature_version"] = UNSIGNED
        client_kwargs: dict[str, Any] = {"config": BotoConfig(**config_kwargs)}
        if endpoint_url:
            client_kwargs["endpoint_url"] = endpoint_url
        if region:
            client_kwargs["region_name"] = region
        client_kwargs["use_ssl"] = use_ssl
        self._client = boto3.client("s3", **session_kwargs, **client_kwargs)
        self._public_presign_client = self._client
        normalized_public_endpoint = str(public_endpoint_url or "").strip()
        # AC17-R130: whether anyone promised this storage is reachable from a browser.
        # Without a public endpoint the client above is the internal one, and signing
        # with it produces a URL to a name that only exists inside the deployment
        # network -- which the browser is then redirected to, and cannot follow.
        self._public_endpoint_configured = bool(normalized_public_endpoint)
        if normalized_public_endpoint:
            public_client_kwargs = dict(client_kwargs)
            public_client_kwargs["endpoint_url"] = normalized_public_endpoint
            self._public_presign_client = boto3.client(
                "s3",
                **session_kwargs,
                **public_client_kwargs,
            )
        self._bucket = str(bucket or "platform-artifacts").strip()
        self._prefix = str(key_prefix or "").strip().rstrip("/")
        self.key_prefix = f"{self._prefix}/" if self._prefix else ""
        self._presign_ttl = max(60, min(int(presign_ttl_seconds or 600), 7 * 24 * 3600))

    def _full_key(self, key: str) -> str:
        safe = str(key or "").strip().lstrip("/")
        return f"{self._prefix}/{safe}" if self._prefix else safe

    def put(self, key: str, body: bytes, *, content_type: str) -> dict[str, Any]:
        payload = bytes(body)
        checksum = hashlib.sha256(payload).hexdigest()
        self._client.put_object(
            Bucket=self._bucket,
            Key=self._full_key(key),
            Body=payload,
            ContentType=str(content_type or OCTET_STREAM_VALUE).strip(),
        )
        return {"key": key, "size_bytes": len(payload), "sha256": checksum}

    def put_stream(
        self,
        key: str,
        chunks: Iterable[bytes],
        *,
        content_type: str,
        max_size_bytes: int,
    ) -> dict[str, Any]:
        max_size = _as_positive_int(max_size_bytes)
        if max_size is None:
            raise ValueError(_MESSAGE_MAX_SIZE_BYTES_MUST_BE_A_POSITIVE_INTEGER)
        full_key = self._full_key(key)
        resolved_content_type = (
            str(content_type or OCTET_STREAM_VALUE).strip() or OCTET_STREAM_VALUE
        )
        upload = self._client.create_multipart_upload(
            Bucket=self._bucket,
            Key=full_key,
            ContentType=resolved_content_type,
        )
        upload_id = str(upload.get("UploadId") or "").strip()
        parts: list[dict[str, Any]] = []
        part_number = 1
        buffer = bytearray()
        part_size = 5 * 1024 * 1024
        digest = hashlib.sha256()
        size = 0

        def _upload_part(payload: bytes) -> None:
            nonlocal part_number
            if not payload:
                return
            response = self._client.upload_part(
                Bucket=self._bucket,
                Key=full_key,
                UploadId=upload_id,
                PartNumber=part_number,
                Body=payload,
            )
            parts.append({"ETag": response["ETag"], "PartNumber": part_number})
            part_number += 1

        try:
            for chunk in chunks:
                data = bytes(chunk or b"")
                if not data:
                    continue
                if size + len(data) > max_size:
                    raise ValueError(_MESSAGE_OBJECT_STREAM_EXCEEDS_MAX_SIZE_BYTES)
                digest.update(data)
                size += len(data)
                view = memoryview(data)
                offset = 0
                while offset < len(view):
                    capacity = part_size - len(buffer)
                    take = min(capacity, len(view) - offset)
                    buffer.extend(view[offset : offset + take])
                    offset += take
                    if len(buffer) == part_size:
                        _upload_part(bytes(buffer))
                        buffer.clear()
            if size == 0:
                with contextlib.suppress(Exception):
                    self._client.abort_multipart_upload(
                        Bucket=self._bucket,
                        Key=full_key,
                        UploadId=upload_id,
                    )
                self._client.put_object(
                    Bucket=self._bucket,
                    Key=full_key,
                    Body=b"",
                    ContentType=resolved_content_type,
                )
                return {"key": key, "size_bytes": 0, "sha256": digest.hexdigest()}
            _upload_part(bytes(buffer))
            self._client.complete_multipart_upload(
                Bucket=self._bucket,
                Key=full_key,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts},
            )
            return {"key": key, "size_bytes": size, "sha256": digest.hexdigest()}
        except Exception:
            with contextlib.suppress(Exception):
                self._client.abort_multipart_upload(
                    Bucket=self._bucket,
                    Key=full_key,
                    UploadId=upload_id,
                )
            raise

    def get(self, key: str) -> bytes | None:
        try:
            response = self._client.get_object(Bucket=self._bucket, Key=self._full_key(key))
            return response["Body"].read()
        except self._client.exceptions.NoSuchKey:
            return None

    def stream(self, key: str, *, chunk_size: int = 1024 * 1024) -> Iterator[bytes]:
        try:
            response = self._client.get_object(Bucket=self._bucket, Key=self._full_key(key))
        except self._client.exceptions.NoSuchKey:
            return
        body = response["Body"]
        if hasattr(body, "iter_chunks"):
            yield from body.iter_chunks(chunk_size=max(1, int(chunk_size or 1)))
            return
        yield from iter(lambda: body.read(max(1, int(chunk_size or 1))), b"")

    def stat(self, key: str) -> dict[str, Any] | None:
        try:
            response = self._client.head_object(Bucket=self._bucket, Key=self._full_key(key))
        except self._client.exceptions.NoSuchKey:
            return None
        except Exception as exc:
            error = getattr(exc, "response", {}).get("Error", {})
            if str(error.get("Code") or "").strip() in {"404", "NoSuchKey", "NotFound"}:
                return None
            raise
        return {"key": key, "size_bytes": int(response.get("ContentLength") or 0)}

    def delete(self, key: str) -> bool:
        try:
            self._client.delete_object(Bucket=self._bucket, Key=self._full_key(key))
            return True
        except Exception:
            return False

    def presign(self, key: str, *, method: str, ttl_seconds: int = 600) -> str:
        safe_method = str(method or "GET").strip().upper()
        if safe_method not in {"GET", "PUT"}:
            raise ValueError(f"presign() only supports GET/PUT; got {safe_method!r}")
        ttl = max(60, min(int(ttl_seconds or 600), self._presign_ttl))
        client_method = "get_object" if safe_method == "GET" else "put_object"
        return self._client.generate_presigned_url(
            ClientMethod=client_method,
            Params={"Bucket": self._bucket, "Key": self._full_key(key)},
            ExpiresIn=ttl,
        )

    def presign_public_download(
        self,
        key: str,
        *,
        filename: str,
        ttl_seconds: int = 600,
    ) -> str:
        """Create a browser-facing GET URL, or nothing when none can be promised.

        AC17-R130: an empty answer is not a failure, it is the honest one. The caller
        streams the authorized object instead, which is what it already does for a
        backend that cannot presign at all. Handing back a URL built on the internal
        endpoint looked like success and sent the browser to a host it cannot resolve:
        a 307 to nowhere, and a Download button that produced nothing.

        This inverts what an empty ARTIFACT_S3_PUBLIC_ENDPOINT_URL used to mean --
        "assume the endpoint is already browser reachable" -- and deliberately. A
        deployment whose S3 endpoint really is public restores the redirect by naming
        it, which the variable exists for; a deployment with bundled storage cannot
        name one, and its downloads now work rather than failing silently. The cost of
        being wrong is bytes through the application; the cost of the old default was
        a feature that did not work at all.
        """

        if not self._public_endpoint_configured:
            return ""
        ttl = max(60, min(int(ttl_seconds or 600), self._presign_ttl))
        safe_filename = _safe_artifact_filename(filename)
        disposition = f"attachment; filename*=UTF-8''{quote(safe_filename, safe='')}"
        return self._public_presign_client.generate_presigned_url(
            ClientMethod="get_object",
            Params={
                "Bucket": self._bucket,
                "Key": self._full_key(key),
                "ResponseContentDisposition": disposition,
            },
            ExpiresIn=ttl,
        )


def create_storage_adapter(config: dict[str, Any] | None = None) -> ObjectStorageAdapter:
    cfg = dict(config or {})
    backend = str(cfg.get("backend") or "memory").strip().lower()
    if backend == "s3":
        return S3ObjectStorageAdapter(
            endpoint_url=str(cfg.get("endpoint_url") or "").strip(),
            public_endpoint_url=str(cfg.get("public_endpoint_url") or "").strip(),
            region=str(cfg.get("region") or "us-east-1").strip(),
            bucket=str(cfg.get("bucket") or "platform-artifacts").strip(),
            access_key=str(cfg.get("access_key") or "").strip(),
            secret_key=str(cfg.get("secret_key") or "").strip(),
            key_prefix=str(cfg.get("key_prefix") or "").strip(),
            use_ssl=bool(cfg.get("use_ssl", True)),
            addressing_style=str(cfg.get("addressing_style") or "auto").strip(),
            presign_ttl_seconds=int(cfg.get("presign_ttl_seconds") or 600),
        )
    if backend == "local_fs":
        return LocalFilesystemStorageAdapter(
            root_dir=str(cfg.get("root_dir") or "/data/artifacts").strip(),
            key_prefix=str(cfg.get("key_prefix") or "").strip(),
        )
    return InMemoryObjectStorage(key_prefix=str(cfg.get("key_prefix") or "").strip())


@dataclass(slots=True)
class ArtifactHandle:
    artifact_id: str


@dataclass(slots=True)
class DatasetHandle:
    dataset_id: str


class ArtifactDatasetPlane:
    def __init__(self, *, storage: ObjectStorageAdapter | None = None) -> None:
        self._storage = storage or InMemoryObjectStorage()
        self._artifacts: dict[str, dict[str, Any]] = {}
        self._datasets: dict[str, dict[str, Any]] = {}

    def create_artifact(
        self,
        *,
        owner_scope: dict[str, Any],
        run_id: str,
        step_id: str,
        filename: str,
        content_type: str,
        retention_class: str = "run_window",
        body: bytes | None = None,
    ) -> tuple[ArtifactHandle, dict[str, Any]]:
        retention = _normalize_retention(retention_class)
        artifact_id = _new_id("art")
        safe_filename = _safe_artifact_filename(filename)
        object_key = f"artifacts/{artifact_id}/{safe_filename}"
        now = time.time()
        content_type_value = str(content_type or OCTET_STREAM_VALUE).strip() or OCTET_STREAM_VALUE
        meta = {
            "artifact_id": artifact_id,
            "owner_scope": dict(owner_scope or {}),
            "run_id": str(run_id or "").strip(),
            "step_id": str(step_id or "").strip(),
            "filename": safe_filename,
            "content_type": content_type_value,
            "retention_class": retention,
            "expires_at": _owner_retention_expiry(retention, now, owner_scope),
            "expired": False,
            "object_key": object_key,
            "size_bytes": 0,
            "sha256": "",
            "preview_text": "",
            "created_at": now,
            "updated_at": now,
        }
        if body is not None:
            stored = self._storage.put(
                object_key,
                bytes(body),
                content_type=content_type_value,
            )
            meta["size_bytes"] = int(stored.get("size_bytes") or 0)
            meta["sha256"] = str(stored.get("sha256") or "").strip()
            meta["preview_text"] = _preview_text(body)
        self._artifacts[artifact_id] = meta
        with contextlib.suppress(Exception):
            self._storage.put(
                _artifact_metadata_key(artifact_id),
                json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                content_type=APPLICATION_JSON_VALUE,
            )
        return ArtifactHandle(artifact_id=artifact_id), dict(meta)

    def create_dataset(
        self,
        *,
        owner_scope: dict[str, Any],
        run_id: str,
        step_id: str,
        schema: dict[str, Any] | None = None,
        rows: list[dict[str, Any]] | None = None,
        retention_class: str = "run_window",
    ) -> tuple[DatasetHandle, dict[str, Any]]:
        retention = _normalize_retention(retention_class)
        dataset_id = _new_id("dst")
        object_key = f"datasets/{dataset_id}/rows.json"
        body = json.dumps(rows or [], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        stored = self._storage.put(object_key, body, content_type=APPLICATION_JSON_VALUE)
        now = time.time()
        meta = {
            "dataset_id": dataset_id,
            "owner_scope": dict(owner_scope or {}),
            "run_id": str(run_id or "").strip(),
            "step_id": str(step_id or "").strip(),
            "retention_class": retention,
            "expires_at": _owner_retention_expiry(retention, now, owner_scope),
            "expired": False,
            "object_key": object_key,
            "schema": dict(schema or {}),
            "row_count": len(rows or []),
            "size_bytes": int(stored.get("size_bytes") or 0),
            "sha256": str(stored.get("sha256") or "").strip(),
            "preview_rows": list((rows or [])[:10]),
            "created_at": now,
            "updated_at": now,
        }
        self._datasets[dataset_id] = meta
        with contextlib.suppress(Exception):
            self._storage.put(
                f"datasets/{dataset_id}/meta.json",
                json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                content_type=APPLICATION_JSON_VALUE,
            )
        return DatasetHandle(dataset_id=dataset_id), dict(meta)

    def get_artifact(self, artifact_id: str) -> dict[str, Any] | None:
        artifact_id = str(artifact_id or "").strip()
        row = self._artifacts.get(artifact_id)
        if row is None:
            with contextlib.suppress(Exception):
                raw = self._storage.get(_artifact_metadata_key(artifact_id))
                candidate = json.loads(raw) if raw else None
                if (
                    isinstance(candidate, dict)
                    and str(candidate.get("artifact_id") or "").strip() == artifact_id
                    and str(candidate.get("object_key") or "").startswith(
                        f"artifacts/{artifact_id}/"
                    )
                ):
                    row = candidate
                    self._artifacts[artifact_id] = row
        return dict(row) if row else None

    def get_dataset(self, dataset_id: str) -> dict[str, Any] | None:
        dataset_id = str(dataset_id or "").strip()
        row = self._datasets.get(dataset_id)
        if row is None:
            with contextlib.suppress(Exception):
                raw = self._storage.get(f"datasets/{dataset_id}/meta.json")
                if raw:
                    row = json.loads(raw)
                    self._datasets[dataset_id] = row
        return dict(row) if row else None

    def artifact_presigned_url(
        self,
        artifact_id: str,
        *,
        method: str,
        ttl_seconds: int = 600,
    ) -> str:
        row = self.get_artifact(artifact_id)
        if not row:
            return ""
        return self._storage.presign(
            str(row.get("object_key") or ""),
            method=method,
            ttl_seconds=ttl_seconds,
        )


def artifact_plane_from_payload(payload: dict[str, Any] | None) -> ArtifactDatasetPlane:
    root = payload if isinstance(payload, dict) else {}
    raw_context = root.get("runtime_context")
    context: dict[str, Any] = raw_context if isinstance(raw_context, dict) else {}
    storage_config = context.get("artifact_storage")
    return ArtifactDatasetPlane(
        storage=create_storage_adapter(storage_config if isinstance(storage_config, dict) else None)
    )


def descriptors_from_payload(
    payload: dict[str, Any] | None,
    *,
    kind: str = "artifact",
    role: str | None = None,
) -> list[dict[str, Any]]:
    root = payload if isinstance(payload, dict) else {}
    normalized_kind = _normalize_descriptor_kind(kind)
    collection_key = "datasets" if normalized_kind == "dataset" else "artifacts"
    raw_collection = root.get(collection_key)
    collection: dict[str, Any] = raw_collection if isinstance(raw_collection, dict) else {}
    roles = [_normalize_descriptor_role(role)] if role else ["input", "output"]
    rows: list[dict[str, Any]] = []
    for item_role in roles:
        key = "inputs" if item_role == "input" else "outputs"
        raw_rows = collection.get(key)
        if not isinstance(raw_rows, list):
            continue
        for row in raw_rows:
            if isinstance(row, dict):
                rows.append(dict(row))
    return rows


def artifact_descriptors_from_payload(
    payload: dict[str, Any] | None,
    *,
    role: str | None = None,
) -> list[dict[str, Any]]:
    return descriptors_from_payload(payload, kind="artifact", role=role)


def dataset_descriptors_from_payload(
    payload: dict[str, Any] | None,
    *,
    role: str | None = None,
) -> list[dict[str, Any]]:
    return descriptors_from_payload(payload, kind="dataset", role=role)


def find_descriptor(
    payload: dict[str, Any] | None,
    *,
    kind: str = "artifact",
    object_id: str = "",
    binding_key: str = "",
    role: str = "input",
) -> dict[str, Any]:
    normalized_kind = _normalize_descriptor_kind(kind)
    normalized_role = _normalize_descriptor_role(role)
    normalized_object_id = _normalize_lookup_id(object_id, kind=normalized_kind)
    normalized_binding_key = str(binding_key or "").strip()
    candidates = descriptors_from_payload(payload, kind=normalized_kind, role=normalized_role)
    if not normalized_object_id and not normalized_binding_key:
        if not candidates:
            raise ArtifactAccessError(
                f"No {normalized_role} {normalized_kind} descriptors in payload"
            )
        return dict(candidates[0])
    id_field = f"{normalized_kind}_id"
    handle_field = f"{normalized_kind}_handle"
    for descriptor in candidates:
        row_id = _normalize_lookup_id(str(descriptor.get(id_field) or ""), kind=normalized_kind)
        row_handle = _normalize_lookup_id(
            str(descriptor.get(handle_field) or ""),
            kind=normalized_kind,
        )
        if normalized_kind == "dataset":
            row_compat_id = _normalize_lookup_id(
                str(descriptor.get("artifact_id") or ""),
                kind=normalized_kind,
            )
            row_compat_handle = _normalize_lookup_id(
                str(descriptor.get("artifact_handle") or ""),
                kind=normalized_kind,
            )
        else:
            row_compat_id = ""
            row_compat_handle = ""
        row_binding = str(descriptor.get("binding_key") or "").strip()
        if normalized_object_id and normalized_object_id in {
            row_id,
            row_handle,
            row_compat_id,
            row_compat_handle,
        }:
            return dict(descriptor)
        if normalized_binding_key and normalized_binding_key == row_binding:
            return dict(descriptor)
    raise ArtifactAccessError(
        f"{normalized_kind.title()} descriptor not found for role '{normalized_role}'"
    )


def find_artifact_descriptor(
    payload: dict[str, Any] | None,
    *,
    artifact_id: str = "",
    binding_key: str = "",
    role: str = "input",
) -> dict[str, Any]:
    return find_descriptor(
        payload,
        kind="artifact",
        object_id=artifact_id,
        binding_key=binding_key,
        role=role,
    )


def find_dataset_descriptor(
    payload: dict[str, Any] | None,
    *,
    dataset_id: str = "",
    binding_key: str = "",
    role: str = "input",
) -> dict[str, Any]:
    return find_descriptor(
        payload,
        kind="dataset",
        object_id=dataset_id,
        binding_key=binding_key,
        role=role,
    )


def stream_descriptor_bytes(
    payload: dict[str, Any] | None,
    *,
    kind: str = "artifact",
    object_id: str = "",
    binding_key: str = "",
    role: str = "input",
    chunk_size: int = 1024 * 1024,
    timeout_seconds: float = 30.0,
) -> Iterator[bytes]:
    normalized_kind = _normalize_descriptor_kind(kind)
    descriptor = find_descriptor(
        payload,
        kind=normalized_kind,
        object_id=object_id,
        binding_key=binding_key,
        role=role,
    )
    access = _descriptor_access(descriptor, mode="read")
    url = str(access.get("download_url") or "").strip()
    if not url:
        raise ArtifactAccessError(f"Input {normalized_kind} descriptor does not include a URL")
    yield from _stream_presigned_url(
        url,
        descriptor=descriptor,
        access=access,
        headers=_descriptor_headers(access),
        timeout_seconds=timeout_seconds,
        chunk_size=chunk_size,
    )


def stream_artifact_bytes(
    payload: dict[str, Any] | None,
    *,
    artifact_id: str = "",
    binding_key: str = "",
    chunk_size: int = 1024 * 1024,
    timeout_seconds: float = 30.0,
) -> Iterator[bytes]:
    yield from stream_descriptor_bytes(
        payload,
        kind="artifact",
        object_id=artifact_id,
        binding_key=binding_key,
        chunk_size=chunk_size,
        timeout_seconds=timeout_seconds,
    )


def stream_dataset_bytes(
    payload: dict[str, Any] | None,
    *,
    dataset_id: str = "",
    binding_key: str = "",
    chunk_size: int = 1024 * 1024,
    timeout_seconds: float = 30.0,
) -> Iterator[bytes]:
    yield from stream_descriptor_bytes(
        payload,
        kind="dataset",
        object_id=dataset_id,
        binding_key=binding_key,
        chunk_size=chunk_size,
        timeout_seconds=timeout_seconds,
    )


def write_descriptor_stream(
    payload: dict[str, Any] | None,
    chunks: Iterable[bytes | bytearray | memoryview | str],
    *,
    kind: str = "artifact",
    object_id: str = "",
    binding_key: str = "",
    content_type: str = "",
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    normalized_kind = _normalize_descriptor_kind(kind)
    descriptor = find_descriptor(
        payload,
        kind=normalized_kind,
        object_id=object_id,
        binding_key=binding_key,
        role="output",
    )
    access = _descriptor_access(descriptor, mode="write")
    url = str(access.get("upload_url") or "").strip()
    if not url:
        raise ArtifactAccessError(f"Output {normalized_kind} descriptor does not include a URL")
    resolved_content_type = (
        str(content_type or descriptor.get("content_type") or OCTET_STREAM_VALUE).strip()
        or OCTET_STREAM_VALUE
    )
    _enforce_platform_grant_content_type(descriptor, access, resolved_content_type)
    result = _write_presigned_url_stream(
        url,
        chunks,
        descriptor=descriptor,
        access=access,
        headers={
            **_descriptor_headers(access),
            "Content-Type": resolved_content_type,
        },
        timeout_seconds=timeout_seconds,
    )
    id_field = f"{normalized_kind}_id"
    handle_field = f"{normalized_kind}_handle"
    written_id = str(descriptor.get(id_field) or descriptor.get("artifact_id") or "").strip()
    announce_output_ready(normalized_kind, written_id)
    return {
        id_field: written_id,
        handle_field: str(
            descriptor.get(handle_field) or descriptor.get("artifact_handle") or ""
        ).strip(),
        "binding_key": str(descriptor.get("binding_key") or "").strip(),
        "content_type": resolved_content_type,
        **result,
    }


def write_artifact_stream(
    payload: dict[str, Any] | None,
    chunks: Iterable[bytes | bytearray | memoryview | str],
    *,
    artifact_id: str = "",
    binding_key: str = "",
    content_type: str = "",
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    return write_descriptor_stream(
        payload,
        chunks,
        kind="artifact",
        object_id=artifact_id,
        binding_key=binding_key,
        content_type=content_type,
        timeout_seconds=timeout_seconds,
    )


def write_dataset_stream(
    payload: dict[str, Any] | None,
    chunks: Iterable[bytes | bytearray | memoryview | str],
    *,
    dataset_id: str = "",
    binding_key: str = "",
    content_type: str = APPLICATION_JSON_VALUE,
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    return write_descriptor_stream(
        payload,
        chunks,
        kind="dataset",
        object_id=dataset_id,
        binding_key=binding_key,
        content_type=content_type,
        timeout_seconds=timeout_seconds,
    )


def descriptor_to_local_path(
    payload: dict[str, Any] | None,
    *,
    kind: str = "artifact",
    object_id: str = "",
    binding_key: str = "",
    suffix: str = "",
    timeout_seconds: float = 30.0,
) -> str:
    """Return a local path for an input descriptor.

    ``file://`` grants return the live store path and must be treated as
    read-only. Remote grants are copied to a caller-owned tempfile; callers
    should remove that file when they no longer need it.
    """
    normalized_kind = _normalize_descriptor_kind(kind)
    descriptor = find_descriptor(
        payload,
        kind=normalized_kind,
        object_id=object_id,
        binding_key=binding_key,
        role="input",
    )
    access = _descriptor_access(descriptor, mode="read")
    url = str(access.get("download_url") or "").strip()
    if not url:
        raise ArtifactAccessError(f"Input {normalized_kind} descriptor does not include a URL")
    if str(urlparse(url).scheme or "").lower() == "file":
        return _file_url_path(url)
    fd, path = tempfile.mkstemp(
        prefix=f"flowsteward_{normalized_kind}_",
        suffix=suffix,
    )
    try:
        with os.fdopen(fd, "wb") as handle:
            for chunk in _stream_presigned_url(
                url,
                descriptor=descriptor,
                access=access,
                headers=_descriptor_headers(access),
                timeout_seconds=timeout_seconds,
            ):
                handle.write(chunk)
    except Exception:
        with contextlib.suppress(Exception):
            os.unlink(path)
        raise
    return path


def artifact_to_local_path(
    payload: dict[str, Any] | None,
    *,
    artifact_id: str = "",
    binding_key: str = "",
    suffix: str = "",
    timeout_seconds: float = 30.0,
) -> str:
    return descriptor_to_local_path(
        payload,
        kind="artifact",
        object_id=artifact_id,
        binding_key=binding_key,
        suffix=suffix,
        timeout_seconds=timeout_seconds,
    )


def dataset_to_local_path(
    payload: dict[str, Any] | None,
    *,
    dataset_id: str = "",
    binding_key: str = "",
    suffix: str = ".json",
    timeout_seconds: float = 30.0,
) -> str:
    return descriptor_to_local_path(
        payload,
        kind="dataset",
        object_id=dataset_id,
        binding_key=binding_key,
        suffix=suffix,
        timeout_seconds=timeout_seconds,
    )


def read_artifact_bytes(
    payload: dict[str, Any] | None,
    *,
    artifact_id: str = "",
    binding_key: str = "",
    timeout_seconds: float = 30.0,
) -> bytes:
    descriptor = find_artifact_descriptor(
        payload,
        artifact_id=artifact_id,
        binding_key=binding_key,
        role="input",
    )
    access = _descriptor_access(descriptor, mode="read")
    url = str(access.get("download_url") or "").strip()
    if not url:
        raise ArtifactAccessError("Input artifact descriptor does not include a download URL")
    return b"".join(
        _stream_presigned_url(
            url,
            descriptor=descriptor,
            access=access,
            headers=_descriptor_headers(access),
            timeout_seconds=timeout_seconds,
        )
    )


def read_dataset_bytes(
    payload: dict[str, Any] | None,
    *,
    dataset_id: str = "",
    binding_key: str = "",
    timeout_seconds: float = 30.0,
) -> bytes:
    return b"".join(
        stream_dataset_bytes(
            payload,
            dataset_id=dataset_id,
            binding_key=binding_key,
            timeout_seconds=timeout_seconds,
        )
    )


def write_artifact_bytes(
    payload: dict[str, Any] | None,
    body: bytes | bytearray | memoryview | str,
    *,
    artifact_id: str = "",
    binding_key: str = "",
    content_type: str = "",
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    descriptor = find_artifact_descriptor(
        payload,
        artifact_id=artifact_id,
        binding_key=binding_key,
        role="output",
    )
    access = _descriptor_access(descriptor, mode="write")
    url = str(access.get("upload_url") or "").strip()
    if not url:
        raise ArtifactAccessError("Output artifact descriptor does not include an upload URL")
    resolved_content_type = (
        str(content_type or descriptor.get("content_type") or OCTET_STREAM_VALUE).strip()
        or OCTET_STREAM_VALUE
    )
    _enforce_platform_grant_content_type(descriptor, access, resolved_content_type)
    payload_bytes = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    _enforce_artifact_body_limits(descriptor, access, payload_bytes)
    _write_presigned_url(
        url,
        payload_bytes,
        descriptor=descriptor,
        access=access,
        headers={
            **_descriptor_headers(access),
            "Content-Type": resolved_content_type,
        },
        timeout_seconds=timeout_seconds,
    )
    written_id = str(descriptor.get("artifact_id") or "").strip()
    announce_output_ready("artifact", written_id)
    return {
        "artifact_id": written_id,
        "artifact_handle": str(descriptor.get("artifact_handle") or "").strip(),
        "binding_key": str(descriptor.get("binding_key") or "").strip(),
        "content_type": resolved_content_type,
        "size_bytes": len(payload_bytes),
        "sha256": hashlib.sha256(payload_bytes).hexdigest(),
    }


def write_dataset_bytes(
    payload: dict[str, Any] | None,
    body: bytes | bytearray | memoryview | str,
    *,
    dataset_id: str = "",
    binding_key: str = "",
    content_type: str = APPLICATION_JSON_VALUE,
    timeout_seconds: float = 30.0,
) -> dict[str, Any]:
    payload_bytes = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    return write_dataset_stream(
        payload,
        [payload_bytes],
        dataset_id=dataset_id,
        binding_key=binding_key,
        content_type=content_type,
        timeout_seconds=timeout_seconds,
    )


def _normalize_descriptor_role(role: str | None) -> str:
    normalized = str(role or "input").strip().lower()
    return "output" if normalized in {"output", "outputs", "write"} else "input"


def _normalize_descriptor_kind(kind: str | None) -> str:
    normalized = str(kind or "artifact").strip().lower()
    return "dataset" if normalized in {"dataset", "datasets"} else "artifact"


def _normalize_lookup_id(value: str, *, kind: str) -> str:
    normalized_kind = _normalize_descriptor_kind(kind)
    normalized = str(value or "").strip()
    prefix = f"{normalized_kind}:"
    if normalized.startswith(prefix):
        return normalized.split(":", 1)[1]
    return normalized


def _descriptor_access(descriptor: dict[str, Any], *, mode: str) -> dict[str, Any]:
    raw_access = descriptor.get("access")
    access: dict[str, Any] = raw_access if isinstance(raw_access, dict) else {}
    transport = str(access.get("transport") or "").strip()
    if transport != "presigned_url":
        raise ArtifactAccessError(
            f"Artifact transport '{transport or 'handle_only'}' is not usable"
        )
    access_mode = str(access.get("mode") or "").strip().lower()
    if mode == "read" and access_mode not in {"read", "read_write"}:
        raise ArtifactAccessError("Artifact grant does not allow reads")
    if mode == "write" and access_mode not in {"write", "read_write"}:
        raise ArtifactAccessError("Artifact grant does not allow writes")
    return dict(access)


def _descriptor_headers(access: dict[str, Any]) -> dict[str, str]:
    headers: dict[str, str] = {}
    raw_headers = access.get("required_headers")
    if isinstance(raw_headers, dict):
        for key, value in raw_headers.items():
            header = str(key or "").strip()
            if header:
                headers[header] = str(value or "")
    return headers


def _private_upload_authority(
    descriptor: dict[str, Any], access: dict[str, Any]
) -> tuple[bool, str]:
    signature = verified_platform_grant_signature(descriptor, access)
    if signature and signature in _consumed_platform_grants:
        raise ArtifactAccessError("Platform artifact upload grant has already been used")
    return bool(signature), signature


def _enforce_platform_grant_content_type(
    descriptor: dict[str, Any],
    access: dict[str, Any],
    content_type: str,
) -> None:
    if not isinstance(access.get("platform_grant"), dict):
        return
    granted_content_type = str(descriptor.get("content_type") or "").strip()
    if not granted_content_type or content_type != granted_content_type:
        raise ArtifactAccessError("Artifact content type does not match the platform upload grant")


def _enforce_artifact_body_limits(
    descriptor: dict[str, Any],
    access: dict[str, Any],
    body: bytes,
) -> None:
    limit = _as_positive_int(access.get("max_size_bytes"))
    if limit is None:
        limit = _as_positive_int(descriptor.get("size_bytes"))
    if limit is not None and len(body) > limit:
        raise ArtifactAccessError(_MESSAGE_ARTIFACT_BODY_EXCEEDS_GRANTED_SIZE_LIMIT)


def _descriptor_size_limit(descriptor: dict[str, Any], access: dict[str, Any]) -> int | None:
    limit = _as_positive_int(access.get("max_size_bytes"))
    if limit is None:
        limit = _as_positive_int(descriptor.get("size_bytes"))
    return limit


def _normalize_chunk(chunk: bytes | bytearray | memoryview | str) -> bytes:
    if isinstance(chunk, str):
        return chunk.encode("utf-8")
    if not isinstance(chunk, (bytes, bytearray, memoryview)):
        raise ArtifactAccessError("Artifact stream chunks must be bytes-like objects or strings")
    return bytes(chunk)


def _stream_presigned_url(
    url: str,
    *,
    descriptor: dict[str, Any],
    access: dict[str, Any],
    headers: dict[str, str],
    timeout_seconds: float,
    chunk_size: int = 1024 * 1024,
) -> Iterator[bytes]:
    parsed = urlparse(url)
    scheme = str(parsed.scheme or "").lower()
    limit = _descriptor_size_limit(descriptor, access)
    expected_sha = str(descriptor.get("checksum_sha256") or "").strip()
    digest = hashlib.sha256()
    total = 0

    def _checked(chunks: Iterable[bytes]) -> Iterator[bytes]:
        nonlocal total
        for raw_chunk in chunks:
            chunk = bytes(raw_chunk)
            if not chunk:
                continue
            next_total = total + len(chunk)
            if limit is not None and next_total > limit:
                raise ArtifactAccessError(_MESSAGE_ARTIFACT_BODY_EXCEEDS_GRANTED_SIZE_LIMIT)
            total = next_total
            digest.update(chunk)
            yield chunk

    if scheme == "file":
        with open(_file_url_path(url), "rb") as handle:
            yield from _checked(iter(lambda: handle.read(max(1, int(chunk_size or 1))), b""))
    elif scheme in {"http", "https"}:
        request = Request(url, method="GET", headers=headers)
        try:
            if verified_platform_grant_signature(descriptor, access):
                response_context = open_platform_artifact_url(
                    request,
                    descriptor=descriptor,
                    access=access,
                    timeout_seconds=float(timeout_seconds),
                )
            else:
                response_context = open_pinned_url(
                    request,
                    timeout_seconds=float(timeout_seconds),
                    purpose="artifact download URL",
                )
            with response_context as response:
                yield from _checked(iter(lambda: response.read(max(1, int(chunk_size or 1))), b""))
        except ArtifactAccessError:
            raise
        except (PinnedPeerError, OSError) as exc:
            raise ArtifactAccessError("Input artifact download failed") from exc
    else:
        raise ArtifactAccessError(f"Unsupported artifact download URL scheme '{scheme}'")

    if expected_sha and digest.hexdigest() != expected_sha:
        raise ArtifactAccessError("Input artifact checksum mismatch")


class _LimitedChunkIterator:
    def __init__(
        self,
        chunks: Iterable[bytes | bytearray | memoryview | str],
        *,
        descriptor: dict[str, Any],
        access: dict[str, Any],
    ) -> None:
        self._chunks = iter(chunks)
        self._limit = _descriptor_size_limit(descriptor, access)
        self._digest = hashlib.sha256()
        self._total = 0

    def __iter__(self) -> _LimitedChunkIterator:
        return self

    def __next__(self) -> bytes:
        while True:
            chunk = _normalize_chunk(next(self._chunks))
            if chunk:
                break
        next_total = self._total + len(chunk)
        if self._limit is not None and next_total > self._limit:
            raise ArtifactAccessError(_MESSAGE_ARTIFACT_BODY_EXCEEDS_GRANTED_SIZE_LIMIT)
        self._total = next_total
        self._digest.update(chunk)
        return chunk

    def result(self) -> dict[str, Any]:
        return {
            "size_bytes": self._total,
            "sha256": self._digest.hexdigest(),
        }


def _spool_limited_chunks(
    chunks: Iterable[bytes | bytearray | memoryview | str],
    *,
    descriptor: dict[str, Any],
    access: dict[str, Any],
) -> tuple[str, dict[str, Any]]:
    iterator = _LimitedChunkIterator(chunks, descriptor=descriptor, access=access)
    fd, path = tempfile.mkstemp(prefix="flowsteward_upload_")
    try:
        with os.fdopen(fd, "wb") as handle:
            for chunk in iterator:
                handle.write(chunk)
        return path, iterator.result()
    except Exception:
        with contextlib.suppress(Exception):
            os.unlink(path)
        raise


def _write_presigned_url_stream(
    url: str,
    chunks: Iterable[bytes | bytearray | memoryview | str],
    *,
    descriptor: dict[str, Any],
    access: dict[str, Any],
    headers: dict[str, str],
    timeout_seconds: float,
) -> dict[str, Any]:
    parsed = urlparse(url)
    scheme = str(parsed.scheme or "").lower()
    iterator = _LimitedChunkIterator(chunks, descriptor=descriptor, access=access)
    if scheme == "file":
        path = _file_url_path(url)
        directory = os.path.dirname(path) or "."
        os.makedirs(directory, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            prefix=f".{os.path.basename(path) or 'artifact'}.",
            dir=directory,
        )
        try:
            with os.fdopen(fd, "wb") as handle:
                for chunk in iterator:
                    handle.write(chunk)
            result = iterator.result()
            os.replace(tmp_path, path)
            return result
        except Exception:
            with contextlib.suppress(Exception):
                os.unlink(tmp_path)
            raise
    if scheme in {"http", "https"}:
        allow_private, signature = _private_upload_authority(descriptor, access)
        path, result = _spool_limited_chunks(chunks, descriptor=descriptor, access=access)
        try:
            request_headers = dict(headers)
            request_headers["Content-Length"] = str(result["size_bytes"])
            with open(path, "rb") as handle:
                request = Request(url, data=handle, method="PUT", headers=request_headers)
                if allow_private:
                    response_context = open_platform_artifact_url(
                        request,
                        descriptor=descriptor,
                        access=access,
                        timeout_seconds=float(timeout_seconds),
                    )
                else:
                    response_context = open_pinned_url(
                        request,
                        timeout_seconds=float(timeout_seconds),
                        purpose="artifact upload URL",
                    )
                with response_context as response:
                    response.read()
            if signature:
                _consumed_platform_grants.add(signature)
            return result
        finally:
            with contextlib.suppress(Exception):
                os.unlink(path)
    raise ArtifactAccessError(f"Unsupported artifact upload URL scheme '{scheme}'")


def _write_presigned_url(
    url: str,
    body: bytes,
    *,
    descriptor: dict[str, Any],
    access: dict[str, Any],
    headers: dict[str, str],
    timeout_seconds: float,
) -> None:
    parsed = urlparse(url)
    scheme = str(parsed.scheme or "").lower()
    if scheme == "file":
        path = _file_url_path(url)
        directory = os.path.dirname(path) or "."
        os.makedirs(directory, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            prefix=f".{os.path.basename(path) or 'artifact'}.",
            dir=directory,
        )
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(body)
            os.replace(tmp_path, path)
        except Exception:
            with contextlib.suppress(Exception):
                os.unlink(tmp_path)
            raise
        return
    if scheme in {"http", "https"}:
        allow_private, signature = _private_upload_authority(descriptor, access)
        request_headers = dict(headers)
        request_headers["Content-Length"] = str(len(body))
        request = Request(url, data=body, method="PUT", headers=request_headers)
        if allow_private:
            response_context = open_platform_artifact_url(
                request,
                descriptor=descriptor,
                access=access,
                timeout_seconds=float(timeout_seconds),
            )
        else:
            response_context = open_pinned_url(
                request,
                timeout_seconds=float(timeout_seconds),
                purpose="artifact upload URL",
            )
        with response_context as response:
            response.read()
        if signature:
            _consumed_platform_grants.add(signature)
        return
    raise ArtifactAccessError(f"Unsupported artifact upload URL scheme '{scheme}'")


def _file_url_path(url: str) -> str:
    parsed = urlparse(url)
    if str(parsed.scheme or "").lower() != "file":
        raise ArtifactAccessError("Expected file URL")
    path = unquote(parsed.path or "")
    if not path:
        raise ArtifactAccessError("File artifact URL does not include a path")
    return path


def _as_positive_int(value: Any) -> int | None:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:24]}"


def _safe_artifact_filename(filename: str | None) -> str:
    value = str(filename or "").strip() or "blob"
    if "\x00" in value or "/" in value or "\\" in value or value in {".", ".."}:
        raise ValueError("Artifact filename must be a plain filename")
    return value


def _normalize_retention(value: str) -> str:
    retention = str(value or "").strip().lower()
    if not retention:
        return "run_window"
    if retention not in RETENTION_CLASSES:
        raise ValueError(f"Unsupported retention_class '{value}'")
    return retention


def _retention_expiry(retention_class: str, now: float) -> float | None:
    if retention_class == "ephemeral":
        return now + 3600
    if retention_class == "run_window":
        return now + 24 * 3600
    if retention_class == "audit":
        return now + 30 * 24 * 3600
    return None


def _owner_retention_expiry(
    retention_class: str,
    now: float,
    owner_scope: dict[str, Any] | None,
) -> float | None:
    if retention_class == "run_window" and str((owner_scope or {}).get("job_id") or "").strip():
        return None
    return _retention_expiry(retention_class, now)


def _preview_text(body: bytes, *, limit: int = 256) -> str:
    text = bytes(body[:limit]).decode("utf-8", errors="replace")
    return "".join(char for char in text if char in "\n\t" or ord(char) >= 32).strip()


__all__ = [
    "APPLICATION_JSON_VALUE",
    "OCTET_STREAM_VALUE",
    "ArtifactAccessError",
    "ArtifactDatasetPlane",
    "ArtifactHandle",
    "DatasetHandle",
    "InMemoryObjectStorage",
    "LocalFilesystemStorageAdapter",
    "ObjectStorageAdapter",
    "S3ObjectStorageAdapter",
    "artifact_descriptors_from_payload",
    "artifact_plane_from_payload",
    "artifact_to_local_path",
    "create_storage_adapter",
    "dataset_descriptors_from_payload",
    "dataset_to_local_path",
    "descriptor_to_local_path",
    "descriptors_from_payload",
    "find_artifact_descriptor",
    "find_dataset_descriptor",
    "find_descriptor",
    "read_artifact_bytes",
    "read_dataset_bytes",
    "stream_artifact_bytes",
    "stream_dataset_bytes",
    "stream_descriptor_bytes",
    "write_artifact_bytes",
    "write_artifact_stream",
    "write_dataset_bytes",
    "write_dataset_stream",
    "write_descriptor_stream",
]

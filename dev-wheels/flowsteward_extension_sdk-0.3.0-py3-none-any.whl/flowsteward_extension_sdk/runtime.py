from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

_MIGRATION_TARGET_TYPES = {
    "install_config",
    "project_connection_config",
    "workspace_data_connection_config",
    "project_state",
}
_FORBIDDEN_MIGRATION_KEYS = {
    "secret",
    "secrets",
    "secret_ref",
    "secret_refs",
    "token",
    "access_token",
    "refresh_token",
    "runtime_token",
    "credential",
    "credentials",
    "encrypted_value",
    "database",
    "db",
    "dsn",
    "host_mutations",
}


@dataclass(frozen=True)
class RuntimeContext:
    account_id: str = ""
    project_id: str = ""
    workflow_id: str = ""
    job_id: str = ""
    phase_id: str = ""
    step_id: str = ""
    artifact_storage: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class RuntimeResources:
    """Typed access to host-authorized resource snapshots."""

    values: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: dict[str, Any] | None) -> RuntimeResources:
        payload = context if isinstance(context, dict) else {}
        resources = payload.get("resources")
        return cls(dict(resources) if isinstance(resources, dict) else {})

    def object(self, name: str) -> dict[str, Any]:
        value = self.values.get(name)
        return dict(value) if isinstance(value, dict) else {}

    def rows(self, name: str) -> list[dict[str, Any]]:
        value = self.values.get(name)
        return (
            [dict(row) for row in value if isinstance(row, dict)] if isinstance(value, list) else []
        )


def _reject_migration_secrets(value: Any) -> None:
    if isinstance(value, dict):
        for key, nested in value.items():
            normalized_key = str(key or "").strip().lower()
            if normalized_key in _FORBIDDEN_MIGRATION_KEYS:
                raise ValueError(f"Migration value contains forbidden secret field '{key}'")
            _reject_migration_secrets(nested)
    elif isinstance(value, list):
        for nested in value:
            _reject_migration_secrets(nested)


@dataclass(frozen=True)
class MigrationEnvelope:
    envelope_version: str
    source_version: int
    target_version: int
    target_type: str
    record_id: str
    value: dict[str, Any]
    namespace: str = ""

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> MigrationEnvelope:
        root = dict(payload or {})
        envelope_version = _text(root.get("envelope_version"))
        if envelope_version != "extension_data_migration_v1":
            raise ValueError("Unsupported migration envelope version")
        target_type = _text(root.get("target_type"))
        if target_type not in _MIGRATION_TARGET_TYPES:
            raise ValueError("Unsupported migration target type")
        record_id = _text(root.get("record_id"))
        if not record_id:
            raise ValueError("Migration record_id is required")
        value = root.get("value")
        if not isinstance(value, dict):
            raise ValueError("Migration value must be an object")
        _reject_migration_secrets(value)
        source_version = int(root.get("source_version") or 0)
        target_version = int(root.get("target_version") or 0)
        if source_version < 1 or target_version <= source_version:
            raise ValueError("Migration versions must move forward")
        return cls(
            envelope_version=envelope_version,
            source_version=source_version,
            target_version=target_version,
            target_type=target_type,
            record_id=record_id,
            namespace=_text(root.get("namespace")),
            value=dict(value),
        )


def migration_result(value: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("Migration result value must be an object")
    _reject_migration_secrets(value)
    return {"value": dict(value)}


def host_mutation(kind: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build a typed host mutation envelope for host-side grant validation."""
    normalized_kind = _text(kind)
    if not normalized_kind:
        raise ValueError("host mutation kind is required")
    return {"kind": normalized_kind, "payload": dict(payload or {})}


def _text(value: Any) -> str:
    return str(value or "").strip()


def runtime_context_from_payload(payload: dict[str, Any] | None) -> RuntimeContext:
    root = payload if isinstance(payload, dict) else {}
    raw_context = root.get("runtime_context")
    context: dict[str, Any] = raw_context if isinstance(raw_context, dict) else {}
    raw_artifact_storage = context.get("artifact_storage")
    artifact_storage = dict(raw_artifact_storage) if isinstance(raw_artifact_storage, dict) else {}
    return RuntimeContext(
        account_id=_text(context.get("account_id")),
        project_id=_text(context.get("project_id")),
        workflow_id=_text(context.get("workflow_id")),
        job_id=_text(context.get("job_id")),
        phase_id=_text(context.get("phase_id")),
        step_id=_text(context.get("step_id")),
        artifact_storage=artifact_storage,
        raw=dict(context),
    )
